//
//  main.c
//  fillit
//
//  Created by Max Vlad on 12/16/16.
//  Copyright © 2016 Max Vlad. All rights reserved.
//

#include <stdio.h>

int main(int argc, const char * argv[]) {
	// insert code here...
	printf("Hello, World!\n");
    return 0;
}
