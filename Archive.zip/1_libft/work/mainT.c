#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "libft.h" /* compile with -I./ */

char	*ft_strrchr(const char *str, int c)
{
	size_t	len;
	char	*ret_str;
	
	len = ft_strlen(str);
	while (len)
	{
		if (str[len] == c)
		{
			ret_str = (char*)&str[len];
			return (ret_str);
		}
		len--;
	}
	return (NULL);
}

int main(void)
{
	char str[] = "Hello je tesx";
	if (strrchr(str, 'H') != ft_strrchr(str, 'H')) {
		printf("original=%s\nft=%s\n", strrchr(str, 'H'), ft_strrchr(str, 'H'));
	}
	if (strrchr(str, 'j') != ft_strrchr(str, 'j')) {
		printf("original=%s\nft=%s\n", strrchr(str, 'j'), ft_strrchr(str, 'j'));
	}
	if (strrchr(str, 'x') != ft_strrchr(str, 'x')) {
		printf("original=%s\nft=%s\n", strrchr(str, 'x'), ft_strrchr(str, 'x'));
	}
	if (strrchr(str, 0) != ft_strrchr(str, 0)) {
		printf("original=%s\nft=%s\n", strrchr(str, 0), ft_strrchr(str, 0));
	}
}
