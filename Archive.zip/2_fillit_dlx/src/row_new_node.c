#include "dlx.h"

t_row	*row_new_node(char *tag, uint var)
{
	t_row	*newNode;

	newNode = (t_row*)malloc(sizeof(t_row));
	newNode->down = NULL;
	newNode->up = NULL;
	newNode->head = NULL;
	newNode->tag = tag;
	newNode->var = var;
	return (newNode);
}
