/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   new_col_node.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mvlad <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/02/01 15:22:50 by mvlad             #+#    #+#             */
/*   Updated: 2017/02/01 15:22:53 by mvlad            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "dlx.h"

t_col	*col_new_node(uint x, uint y)
{
	t_col *newNode;

	newNode = (t_col*)malloc(sizeof(t_col));
	newNode->x = x;
	newNode->y = y;
	newNode->n = 0;
	newNode->left = NULL;
	newNode->right = NULL;
	newNode->head = NULL;
	return (newNode);
}
