#include "dlx.h"

/*
** Inserts the node at the end of the corresponding COLUMN or/and ROW.
*/
void	nod_ins_end(t_col **cur_col, t_row **cur_row)
{
	t_col	*cur_c;
	t_row	*cur_r;

	cur_c = *cur_col;
	cur_r = *cur_row;
	if (cur_r->head == NULL && cur_c->head == NULL)
		nod_ins_end_empty(cur_col, cur_row);
	else if (cur_r->head != NULL && cur_c->head == NULL)
		nod_ins_end_row(cur_col, cur_row);
	else if (cur_r->head == NULL && cur_c->head != NULL)
		nod_ins_end_col(cur_col, cur_row);
	else
		nod_ins_end_full(cur_col, cur_row);
}
