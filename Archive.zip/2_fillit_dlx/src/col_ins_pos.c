/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   col_ins_pos.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mvlad <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/02/02 15:23:35 by mvlad             #+#    #+#             */
/*   Updated: 2017/02/02 15:23:38 by mvlad            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "dlx.h"

static void	col_ins(t_col **cHead, uint x, uint y, uint n)
{
	t_col				*newNode;
	t_col				*current;
	uint				len;

	len = 0;
	current = *cHead;
	while (current->right != *cHead && len++ < n)
		current = current->right;
	if (current->right == *cHead)
	{
		col_ins_end(cHead, x, y);
		return ;
	}
	else
	{
		newNode = col_new_node(x, y);
		newNode->right = current->right;
		newNode->left = current;
		current->right->left = newNode;
		current->right = newNode;
	}
}

void		col_ins_pos(t_col **cHead, uint x, uint y, uint n)
{
	if (*cHead == NULL || n == 0)
	{
		col_ins_beg(cHead, x, y);
		return ;
	}
	else
	{
		col_ins(cHead, x, y, n);
	}
}
