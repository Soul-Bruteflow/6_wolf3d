#include "dlx.h"

/*
** Generates variations of ROW nodes with 4 NOD nodes.
** e.g. A0,A1, etc.
*/
/*
void	row_gen_var(t_col **c_head, t_row **r_head, t_nod **n_head, char *tag, uint *pos)
{
	uint var;

	var = 0;
	row_ins_end(r_head, tag, var);
	nod_create_row(&c_head, &cur_row, &pos[0]);
}
*/
