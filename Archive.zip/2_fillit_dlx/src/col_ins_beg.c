/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   col_ins_beg.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mvlad <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/02/02 13:41:33 by mvlad             #+#    #+#             */
/*   Updated: 2017/02/02 13:41:43 by mvlad            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "dlx.h"

void	col_ins_beg(t_col **cHead, uint x, uint y)
{
	t_col *newNode;
	t_col *current;

	if (*cHead == NULL)
	{
		*cHead = col_new_node(x, y);
		current = *cHead;
		current->left = *cHead;
		current->right = *cHead;
		return ;
	}
	else
	{
		current = *cHead;
		newNode = col_new_node(x, y);
		newNode->right = current;
		newNode->left = current->left;
		current->left->right = newNode;
		current->left = newNode;
		*cHead = newNode;
		return ;
	}
}
