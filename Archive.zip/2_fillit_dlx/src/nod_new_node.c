#include "dlx.h"

t_nod	*nod_new_node(void)
{
	t_nod *new_node;

	new_node = (t_nod*)malloc(sizeof(t_nod));
	new_node->up = NULL;
	new_node->down = NULL;
	new_node->left = NULL;
	new_node->right = NULL;
	new_node->col = NULL;
	new_node->row = NULL;
	return (new_node);
}