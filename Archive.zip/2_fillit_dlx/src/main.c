/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mvlad <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/02/06 16:56:32 by mvlad             #+#    #+#             */
/*   Updated: 2017/02/06 16:56:34 by mvlad            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include "dlx.h"

int	main(void)
{
	/*
	t_row *rHead;
	t_row *current;

	rHead = NULL;
	row_ins_pos(&rHead, "A", 0, 0);
	row_ins_pos(&rHead, "A",1, 1);
	row_ins_pos(&rHead, "B",0, 2);
	row_ins_pos(&rHead, "B",1, 3);
	row_ins_pos(&rHead, "G",1, 2);
	current = rHead;
	while (current->down != rHead)
	{
		printf("tag - %s, variation - %d\n", current->tag, current->var);
		current = current->down;
	}
	printf("tag - %s, variation - %d\n", current->tag, current->var);
	*/

	t_col *c_head;
	//t_nod *n_head;
	//t_nod *cur_nod;
	//t_nod *cur_nod2;
	t_col *cur_col;
	//t_row *r_head;
	//t_row *cur_row;
	//uint	pos[] = {0,0,2,2,3,3,5,5};
	//uint	pos2[] = {1,0,2,1,3,3,5,5};

	//n_head = NULL;
	//r_head = NULL;
	c_head = NULL;
	col_generate(&c_head, 5, 5);
	cur_col = c_head;
	while (cur_col->right != c_head)
	{
		printf("x:%d, y:%d| ", cur_col->x, cur_col->y);
		cur_col = cur_col->right;
	}
	printf("x:%d, y:%d|\n\n", cur_col->x, cur_col->y);

	cur_col->right->left = cur_col->left;
	cur_col->left->right = cur_col->right;

	cur_col->right->left = cur_col;
	cur_col->left->right = cur_col;

	cur_col = c_head;
	while (cur_col->right != c_head)
	{
		printf("x:%d, y:%d| ", cur_col->x, cur_col->y);
		cur_col = cur_col->right;
	}
	printf("x:%d, y:%d|\n\n", cur_col->x, cur_col->y);

	cur_col->right->left = cur_col;
	cur_col->left->right = cur_col;

	cur_col = c_head;
	while (cur_col->right != c_head)
	{
		printf("x:%d, y:%d| ", cur_col->x, cur_col->y);
		cur_col = cur_col->right;
	}
	printf("x:%d, y:%d|\n\n", cur_col->x, cur_col->y);
	/*
	row_ins_end(&r_head, "A", 0);

	cur_row = r_head;
	while (cur_row->down != r_head)
		cur_row = cur_row->down;
	//col_expand(&cHead, 5);

	nod_create_row(&c_head, &cur_row, &pos[0]);

	row_ins_end(&r_head, "A", 0);

	cur_row = r_head;
	while (cur_row->down != r_head)
		cur_row = cur_row->down;
	nod_create_row(&c_head, &cur_row, &pos2[0]);

	n_head = r_head->head;
	cur_nod = n_head;
	while (cur_nod->right != n_head)
	{
		printf("x:%d, y:%d| ", cur_nod->col->x, cur_nod->col->y);
		cur_nod = cur_nod->right;
	}
	printf("x:%d, y:%d|\n\n", cur_nod->col->x, cur_nod->col->y);

	cur_nod = r_head->head->down;
	cur_nod2 = r_head->head->down;
	while (cur_nod->right != cur_nod2)
	{
		printf("x:%d, y:%d| ", cur_nod->col->x, cur_nod->col->y);
		cur_nod = cur_nod->right;
	}
	printf("x:%d, y:%d|\n\n", cur_nod->col->x, cur_nod->col->y);
*/

 /*
	current = cHead;
	while (current->right != cHead)
	{
		printf("x %d, y %d | ", current->x, current->y);
		if (current->x > current->right->x)
		{
			printf("\n");
		}
		current = current->right;
	}
	printf("x %d, y %d | ", current->x, current->y);
	*/
	return (0);

}
