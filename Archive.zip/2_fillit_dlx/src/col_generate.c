/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   col_generate.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mvlad <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/02/06 16:40:41 by mvlad             #+#    #+#             */
/*   Updated: 2017/02/06 16:40:43 by mvlad            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "dlx.h"

/*
** This function generates N nodes of the dlx column list.
*/

void	col_generate(t_col **cHead, uint x, uint y)
{
	uint	 cur_x;
	uint	 cur_y;

	cur_y = 0;
	while (cur_y <= y)
	{
		cur_x = 0;
		while (cur_x <= x)
		{
			col_ins_end(cHead, cur_x, cur_y);
			cur_x++;
		}
		cur_y++;
	}
}
