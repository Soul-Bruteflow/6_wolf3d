/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   col_expand.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mvlad <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/02/06 16:40:50 by mvlad             #+#    #+#             */
/*   Updated: 2017/02/06 16:40:58 by mvlad            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "dlx.h"

/*
** This function expands the dlx column list by N nodes.
** For example given list of X Y coordinates 1x1. We want to expand it to 2x2;
** before - x0,y0, x1,y0 | x0,y1, x1,y1;
** after  - x0,y0, x1,y0, x2,y0 | x0,y1, x1,y1, x2,y1 | x0,y2, x1,y2, x2,y2;
** First part  - col_expand  - inserts all in-between values.
** e.g. x2,y0;
** Second part - tail_expand - inserts tail node of the original list
** e.g. x2,y1;
** Third part  - new_expand  - inserts set of new tail nodes
** e.g. x0,y2, x1,y2, x2,y2;
*/

static void		tail_expand(t_col *c, t_col **b, uint new_x)
{
	t_col				*current;
	uint				n;

	current = *b;
	n = new_x - current->left->x;
	while (n > 0)
	{
		col_ins_end(b, (c->x + 1), c->y);
		n--;
		c = c->right;
	}
}

static void		new_expand(t_col **cHead, uint new_x, uint dif)
{
	uint				n;
	uint				i;
	uint				old_y;
	t_col				*current;

	current = *cHead;
	n = dif;
	old_y = current->left->y;
	while (n > 0)
	{
		i = 0;
		while (i <= new_x)
		{
			col_ins_end(cHead, i, old_y + 1);
			i++;
		}
		old_y++;
		n--;
	}
}

void			col_expand(t_col **cHead, uint new_x)
{
	t_col				*current;
	uint				n;
	uint				len;
	uint				dif;

	len = 0;
	current = *cHead;
	dif = new_x - current->left->x;
	while (current->right != *cHead)
	{
		if (current->x > current->right->x)
		{
			n = dif;
			while (n-- > 0)
			{
				col_ins_pos(cHead, (current->x + 1), current->y, len);
				len++;
				current = current->right;
			}
		}
		current = current->right;
		len++;
	}
	tail_expand(current, cHead, new_x);
	new_expand(cHead, new_x, dif);
}
