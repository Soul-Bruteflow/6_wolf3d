#include "dlx.h"

static void	row_ins(t_row **rHead, char *tag, uint var, uint n)
{
	t_row				*newNode;
	t_row				*current;
	uint				len;

	len = 0;
	current = *rHead;
	while (current->down != *rHead && len++ < n)
		current = current->down;
	if (current->down == *rHead)
	{
		row_ins_end(rHead, tag, var);
		return ;
	}
	else
	{
		current = current->up;
		newNode = row_new_node(tag, var);
		newNode->up = current;
		newNode->down = current->down;
		current->down->up = newNode;
		current->down = newNode;
	}
}

void		row_ins_pos(t_row **rHead, char *tag, uint var, uint n)
{
	if (*rHead == NULL || n == 0)
	{
		row_ins_beg(rHead, tag, var);
		return ;
	}
	else
	{
		row_ins(rHead, tag, var, n);
	}
}
