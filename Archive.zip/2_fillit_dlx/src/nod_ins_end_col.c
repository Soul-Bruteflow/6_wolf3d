#include "dlx.h"

/*
** Inserts the node at the end of the COLUMN list
** when the current ROW head is NULL.
*/
void	nod_ins_end_col(t_col **cur_col, t_row **cur_row)
{
	t_nod	*new_node;
	t_col	*cur_c;
	t_row	*cur_r;

	cur_c = *cur_col;
	cur_c->n += 1;
	cur_r = *cur_row;
	new_node = nod_new_node();
	cur_r->head = new_node;
	new_node->col = cur_c;
	new_node->row = cur_r;
	new_node->up = cur_c->head->up;
	new_node->down = cur_c->head;
	new_node->right = new_node;
	new_node->left = new_node;
	cur_c->head->up->down = new_node;
	cur_c->head->up = new_node;
}
