#include "dlx.h"

void	row_ins_end(t_row **rHead, char *tag, uint var)
{
	t_row	*newNode;
	t_row	*current;

	if (*rHead == NULL)
	{
		row_ins_beg(rHead, tag, var);
		return ;
	}
	else
	{
		current = *rHead;
		newNode = row_new_node(tag, var);
		newNode->up = current->up;
		newNode->down = current;
		current->up->down = newNode;
		current->up = newNode;
		return ;
	}
}
