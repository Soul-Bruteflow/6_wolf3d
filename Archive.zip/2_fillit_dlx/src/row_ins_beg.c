#include "dlx.h"

void	row_ins_beg(t_row **rHead, char *tag, uint var)
{
	t_row	*newNode;
	t_row	*current;

	if (*rHead == NULL)
	{
		*rHead = row_new_node(tag, var);
		current = *rHead;
		current->down = *rHead;
		current->up = *rHead;
		return ;
	}
	else
	{
		current = *rHead;
		newNode = row_new_node(tag, var);
		newNode->down = current;
		newNode->up = current->up;
		current->up->down = newNode;
		current->up = newNode;
		*rHead = newNode;
		return ;
	}
}
