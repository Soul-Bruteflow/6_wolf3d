#include "dlx.h"

/*
** Takes current row pointer, head col pointer. And int with N numbers.
** int array must be in ascending order - {0,0,1,0,2,0,3,0}
** and not - {0,5,1,0,2,0,3,0}
** and must be in range of generated col list
*/
void		nod_create_row(t_col **c_head, t_row **cur_row, uint *pos)
{
	t_col	*cur_col;
	uint	cur_x;
	uint 	cur_y;

	cur_x = 0;
	cur_y = 1;
	cur_col = *c_head;
	while (cur_col->right != *c_head)
	{
		if (cur_col->x == *(pos + cur_x) && cur_col->y == *(pos + cur_y))
		{
			nod_ins_end(&cur_col, cur_row);
			cur_x += 2;
			cur_y += 2;
		}
		cur_col = cur_col->right;
	}
	if (cur_col->x == *(pos + cur_x) && cur_col->y == *(pos + cur_y))
		nod_ins_end(&cur_col, cur_row);
}