#include "dlx.h"

/*
** Creates the node of nod list if the list is EMPTY.
*/
void	nod_ins_end_empty(t_col **cur_col, t_row **cur_row)
{
	t_nod	*new_node;
	t_col	*cur_c;
	t_row	*cur_r;

	cur_c = *cur_col;
	cur_c->n += 1;
	cur_r = *cur_row;
	new_node = nod_new_node();
	cur_c->head = new_node;
	cur_r->head = new_node;
	new_node->col = cur_c;
	new_node->row = cur_r;
	new_node->up = new_node;
	new_node->down = new_node;
	new_node->right = new_node;
	new_node->left = new_node;
}
