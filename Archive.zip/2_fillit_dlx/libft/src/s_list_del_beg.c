/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   s_list_del_beg.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mvlad <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/01/27 13:49:18 by mvlad             #+#    #+#             */
/*   Updated: 2017/01/27 13:53:16 by mvlad            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	s_list_del_beg(t_slist **head)
{
	t_slist		*current;

	current = *head;
	if (current->next == NULL)
	{
		return ;
	}
	else
	{
		*head = current->next;
		current->next = NULL;
		current->data = 0;
		free(current);
	}
}
