/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   s_list_ins_end.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mvlad <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/01/27 13:50:45 by mvlad             #+#    #+#             */
/*   Updated: 2017/01/27 13:50:46 by mvlad            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	s_list_ins_end(t_slist **tail, int data)
{
	t_slist *new_node;
	t_slist *current;

	current = *tail;
	new_node = s_list_new_node(data);
	current->next = new_node;
	*tail = new_node;
}
