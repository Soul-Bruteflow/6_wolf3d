/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   s_list_new_node.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mvlad <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/01/27 13:51:14 by mvlad             #+#    #+#             */
/*   Updated: 2017/01/27 13:52:37 by mvlad            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

t_slist		*s_list_new_node(int data)
{
	t_slist *new_node;

	new_node = (t_slist*)malloc(sizeof(t_slist));
	new_node->data = data;
	new_node->next = NULL;
	return (new_node);
}
