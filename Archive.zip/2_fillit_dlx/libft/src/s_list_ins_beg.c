/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   s_list_ins_beg.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mvlad <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/01/27 13:50:37 by mvlad             #+#    #+#             */
/*   Updated: 2017/01/27 13:55:57 by mvlad            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void		s_list_ins_beg(t_slist **head_ref, int data)
{
	t_slist		*new_node;

	new_node = s_list_new_node(data);
	new_node->next = *head_ref;
	*head_ref = new_node;
}
