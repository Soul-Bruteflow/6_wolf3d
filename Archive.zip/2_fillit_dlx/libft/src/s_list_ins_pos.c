/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   s_list_ins_pos.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mvlad <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/01/27 13:50:52 by mvlad             #+#    #+#             */
/*   Updated: 2017/01/27 14:10:51 by mvlad            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void		s_list_ins_mid_end(t_slist **head, t_slist **tail, int data, int n)
{
	int			i;
	t_slist		*new_node;
	t_slist		*current;

	i = 1;
	current = *head;
	while (current != NULL)
	{
		if (i == n - 1)
		{
			if (current->next->next == NULL)
			{
				s_list_ins_end(tail, data);
				return ;
			}
			else
			{
				new_node = s_list_new_node(data);
				new_node->next = current->next;
				current->next = new_node;
			}
		}
		current = current->next;
		i++;
	}
}

void		s_list_ins_pos(t_slist **head, t_slist **tail, int data, int n)
{
	if (n == 1)
	{
		s_list_ins_beg(head, data);
	}
	else
	{
		s_list_ins_mid_end(head, tail, data, n);
	}
}
