/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   s_list_del_pos.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mvlad <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/01/27 13:49:58 by mvlad             #+#    #+#             */
/*   Updated: 2017/01/27 14:15:51 by mvlad            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	s_list_del_pos_mid(t_slist **head, int n)
{
	int			i;
	t_slist		*tmp;
	t_slist		*del;

	i = 1;
	tmp = *head;
	while (tmp != NULL)
	{
		del = tmp;
		if (i == n)
		{
			del->next = del->next->next;
			tmp->next = NULL;
			tmp->data = 0;
			free(tmp);
		}
		tmp = tmp->next;
		i++;
	}
}

void	s_list_del_pos(t_slist **head, t_slist **tail, int n)
{
	t_slist		*tmp;

	tmp = *head;
	if (n == 1 && tmp->next == NULL)
	{
		s_list_del_beg(head);
		*tail = tmp;
	}
	else if (n == 1)
	{
		s_list_del_beg(head);
	}
	else if (tmp->next == NULL)
	{
		s_list_del_end(tail, *head);
	}
	else
	{
		s_list_del_pos_mid(head, n);
	}
}
