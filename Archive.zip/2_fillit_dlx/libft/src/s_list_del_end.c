/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   s_list_del_end.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mvlad <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/01/27 13:49:46 by mvlad             #+#    #+#             */
/*   Updated: 2017/01/27 13:54:15 by mvlad            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void		s_list_del_end(t_slist **tail, t_slist *head)
{
	t_slist		*tmp;

	tmp = head;
	if (head->next == NULL)
	{
		return ;
	}
	else
	{
		while (head->next)
		{
			tmp = head;
			head = head->next;
		}
		tmp->next = NULL;
		head->data = 0;
		head->next = NULL;
		free(head);
		*tail = tmp;
	}
}
