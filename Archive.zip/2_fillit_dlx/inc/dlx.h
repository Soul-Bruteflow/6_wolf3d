/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   dlx.h                                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mvlad <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/01/27 14:17:48 by mvlad             #+#    #+#             */
/*   Updated: 2017/01/27 14:37:07 by mvlad            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef __DLX_H
# define __DLX_H

# include "libft.h"

typedef unsigned int uint;
/*
** The node structure of the dlx linked list.
*/
typedef	struct			s_nod
{
	struct s_nod		*left;
	struct s_nod		*right;
	struct s_nod		*up;
	struct s_nod		*down;
	struct s_col		*col;
	struct s_row		*row;
}						t_nod;
/*
** The column structure of the dlx linked list.
** Contains matrix X and Y coordinates.
** n - number of s_nodes in the column.
*/
typedef struct			s_col
{
	uint				x;
	uint				y;
	uint				n;
	struct s_nod		*head;
	struct s_col		*left;
	struct s_col		*right;
}						t_col;
/*
** The row structure of the dlx linked list.
** char *tag - tetromino identifier A-Z. Maximum number of tetrominos is 26.
** And N variants of placement for each tag.
*/
typedef struct			s_row
{
	char				*tag;
	uint				var;
	struct s_nod		*head;
	struct s_row		*up;
	struct s_row		*down;
}						t_row;
/*
** dlx linked list - create new COLUMN node
*/
t_col					*col_new_node(uint x, uint y);
void					col_ins_beg(t_col **cHead, uint x, uint y);
void					col_ins_end(t_col **cHead, uint x, uint y);
void					col_ins_pos(t_col **cHead, uint x, uint y, uint n);
void					col_generate (t_col **cHead, uint x, uint y);
void					col_expand(t_col **cHead, uint new_x);
/*
** dlx linked list - create new ROW node
*/
t_row					*row_new_node(char *tag, uint var);
void					row_ins_beg(t_row **rHead, char *tag, uint var);
void					row_ins_end(t_row **rHead, char *tag, uint var);
void					row_ins_pos(t_row **rHead, char *t, uint v, uint n);
/*
** dlx linked list - create new NOD node
*/
t_nod					*nod_new_node(void);
void					nod_ins_end_empty(t_col	**cur_col, t_row **cur_row);
void					nod_ins_end_row(t_col **cur_col, t_row **cur_row);
void					nod_ins_end_col(t_col **cur_col, t_row **cur_row);
void					nod_ins_end_full(t_col **cur_col, t_row **cur_row);
void					nod_ins_end(t_col **cur_col, t_row **cur_row);

void					nod_create_row(t_col **c_head, t_row **cur_row, uint *pos);
#endif